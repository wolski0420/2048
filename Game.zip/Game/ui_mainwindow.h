/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QVBoxLayout *verticalLayout;
    QWidget *infoWidget;
    QHBoxLayout *horizontalLayout_2;
    QVBoxLayout *actualScoreLayout;
    QLabel *actualScoreHeader;
    QLabel *actualScoreLabel;
    QVBoxLayout *buttonLayout;
    QPushButton *instructionButton;
    QPushButton *resetButton;
    QVBoxLayout *bestScoreLayout;
    QLabel *bestScoreHeader;
    QLabel *bestScoreLabel_2;
    QWidget *gameWidget;
    QVBoxLayout *verticalLayout_3;
    QVBoxLayout *layoutForGameAdd;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(618, 719);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        verticalLayout = new QVBoxLayout(centralwidget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        infoWidget = new QWidget(centralwidget);
        infoWidget->setObjectName(QString::fromUtf8("infoWidget"));
        horizontalLayout_2 = new QHBoxLayout(infoWidget);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        actualScoreLayout = new QVBoxLayout();
        actualScoreLayout->setObjectName(QString::fromUtf8("actualScoreLayout"));
        actualScoreHeader = new QLabel(infoWidget);
        actualScoreHeader->setObjectName(QString::fromUtf8("actualScoreHeader"));

        actualScoreLayout->addWidget(actualScoreHeader, 0, Qt::AlignHCenter);

        actualScoreLabel = new QLabel(infoWidget);
        actualScoreLabel->setObjectName(QString::fromUtf8("actualScoreLabel"));

        actualScoreLayout->addWidget(actualScoreLabel, 0, Qt::AlignHCenter);


        horizontalLayout_2->addLayout(actualScoreLayout);

        buttonLayout = new QVBoxLayout();
        buttonLayout->setObjectName(QString::fromUtf8("buttonLayout"));
        instructionButton = new QPushButton(infoWidget);
        instructionButton->setObjectName(QString::fromUtf8("instructionButton"));
        instructionButton->setMinimumSize(QSize(0, 25));

        buttonLayout->addWidget(instructionButton);

        resetButton = new QPushButton(infoWidget);
        resetButton->setObjectName(QString::fromUtf8("resetButton"));
        resetButton->setMinimumSize(QSize(0, 25));

        buttonLayout->addWidget(resetButton);


        horizontalLayout_2->addLayout(buttonLayout);

        bestScoreLayout = new QVBoxLayout();
        bestScoreLayout->setObjectName(QString::fromUtf8("bestScoreLayout"));
        bestScoreHeader = new QLabel(infoWidget);
        bestScoreHeader->setObjectName(QString::fromUtf8("bestScoreHeader"));
        bestScoreHeader->setStyleSheet(QString::fromUtf8("text-align: center"));

        bestScoreLayout->addWidget(bestScoreHeader, 0, Qt::AlignHCenter);

        bestScoreLabel_2 = new QLabel(infoWidget);
        bestScoreLabel_2->setObjectName(QString::fromUtf8("bestScoreLabel_2"));

        bestScoreLayout->addWidget(bestScoreLabel_2, 0, Qt::AlignHCenter);


        horizontalLayout_2->addLayout(bestScoreLayout);


        verticalLayout->addWidget(infoWidget, 0, Qt::AlignVCenter);

        gameWidget = new QWidget(centralwidget);
        gameWidget->setObjectName(QString::fromUtf8("gameWidget"));
        gameWidget->setEnabled(true);
        verticalLayout_3 = new QVBoxLayout(gameWidget);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        layoutForGameAdd = new QVBoxLayout();
        layoutForGameAdd->setObjectName(QString::fromUtf8("layoutForGameAdd"));

        verticalLayout_3->addLayout(layoutForGameAdd);


        verticalLayout->addWidget(gameWidget);

        MainWindow->setCentralWidget(centralwidget);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        actualScoreHeader->setText(QCoreApplication::translate("MainWindow", "Score:", nullptr));
        actualScoreLabel->setText(QString());
        instructionButton->setText(QCoreApplication::translate("MainWindow", "Instruction", nullptr));
        resetButton->setText(QCoreApplication::translate("MainWindow", "Reset Game", nullptr));
        bestScoreHeader->setText(QCoreApplication::translate("MainWindow", "Best score:", nullptr));
        bestScoreLabel_2->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
